var _palette_8cs =
[
    [ "echo17.EnhancedUI.EnhancedGrid.Palette", "structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_palette.html", "structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_palette" ]
];