var structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_cell_properties =
[
    [ "CellProperties", "structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_cell_properties.html#ac1c4e8aa783b34f28ab9ddb42b453390", null ],
    [ "expansionWeight", "structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_cell_properties.html#a150936810d3e6fa08fe3dcd8ea790174", null ],
    [ "minSize", "structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_cell_properties.html#aa645f6bcb5bd03fcdaf8916b5faf7083", null ]
];