var searchData=
[
  ['backward_0',['Backward',['../classecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_enhanced_grid.html#ae73e17aded97c8787afbefd0c5f02cafab3263eb38f8903efc271cc7a760da510',1,'echo17::EnhancedUI::EnhancedGrid::EnhancedGrid']]],
  ['bottomtotoplefttoright_1',['BottomToTopLeftToRight',['../classecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_enhanced_grid.html#a7270687cb58c895b99912997d1411ee4ad9ee15024bc5561da8f9d8ddcbcdb962',1,'echo17::EnhancedUI::EnhancedGrid::EnhancedGrid']]],
  ['bottomtotoprighttoleft_2',['BottomToTopRightToLeft',['../classecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_enhanced_grid.html#a7270687cb58c895b99912997d1411ee4ab01634f19415917a46a158aa536d384e',1,'echo17::EnhancedUI::EnhancedGrid::EnhancedGrid']]]
];
