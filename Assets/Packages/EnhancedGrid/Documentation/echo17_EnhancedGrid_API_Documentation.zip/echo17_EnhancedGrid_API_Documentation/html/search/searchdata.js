var indexSectionsWithContent =
{
  0: "_abcdefgijlmnoprstuvwxy",
  1: "bcefgilopv",
  2: "e",
  3: "bcefgiopv",
  4: "_acdfgijlmoprstuv",
  5: "_acdefglmrsuv",
  6: "cet",
  7: "bcefilnrstxy",
  8: "cdefgilmnorstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties"
};

