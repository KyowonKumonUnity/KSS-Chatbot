var searchData=
[
  ['palette_2ecs_0',['Palette.cs',['../_palette_8cs.html',1,'']]]
];
