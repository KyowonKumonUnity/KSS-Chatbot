var searchData=
[
  ['maxcellsize_0',['maxCellSize',['../classecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_group_layout.html#a8711486dd5a1a024fb2eaab17c993e70',1,'echo17::EnhancedUI::EnhancedGrid::GroupLayout']]],
  ['minsize_1',['minSize',['../structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_cell_properties.html#aa645f6bcb5bd03fcdaf8916b5faf7083',1,'echo17::EnhancedUI::EnhancedGrid::CellProperties']]]
];
