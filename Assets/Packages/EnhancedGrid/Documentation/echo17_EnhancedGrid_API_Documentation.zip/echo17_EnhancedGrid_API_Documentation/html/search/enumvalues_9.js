var searchData=
[
  ['toptobottomlefttoright_0',['TopToBottomLeftToRight',['../classecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_enhanced_grid.html#a7270687cb58c895b99912997d1411ee4a796940448112b99898997f2690c854ab',1,'echo17::EnhancedUI::EnhancedGrid::EnhancedGrid']]],
  ['toptobottomrighttoleft_1',['TopToBottomRightToLeft',['../classecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_enhanced_grid.html#a7270687cb58c895b99912997d1411ee4ab4f47bcc857c500769080b022e97b2d2',1,'echo17::EnhancedUI::EnhancedGrid::EnhancedGrid']]]
];
