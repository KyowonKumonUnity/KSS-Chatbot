var searchData=
[
  ['update_0',['Update',['../classecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_enhanced_grid.html#ae77414afb3b57c6736d31e73458ec6b4',1,'echo17::EnhancedUI::EnhancedGrid::EnhancedGrid']]],
  ['updatecell_1',['UpdateCell',['../interfaceecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_i_enhanced_grid_delegate.html#a2552ba921173864992bacca455fad2c2',1,'echo17::EnhancedUI::EnhancedGrid::IEnhancedGridDelegate']]]
];
