var searchData=
[
  ['palette_0',['palette',['../structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_palette.html',1,'echo17.EnhancedUI.EnhancedGrid.Palette'],['../structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_palette.html#a0e4e1fed42db3cde48d25550a766814c',1,'echo17.EnhancedUI.EnhancedGrid.Palette.Palette()']]],
  ['palette_2ecs_1',['Palette.cs',['../_palette_8cs.html',1,'']]]
];
