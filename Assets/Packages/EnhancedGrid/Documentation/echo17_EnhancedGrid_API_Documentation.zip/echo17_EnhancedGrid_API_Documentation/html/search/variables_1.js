var searchData=
[
  ['actualsize_0',['actualSize',['../classecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_cell_layout.html#a3c0e166443e491376303d8738c3a5f06',1,'echo17::EnhancedUI::EnhancedGrid::CellLayout']]]
];
