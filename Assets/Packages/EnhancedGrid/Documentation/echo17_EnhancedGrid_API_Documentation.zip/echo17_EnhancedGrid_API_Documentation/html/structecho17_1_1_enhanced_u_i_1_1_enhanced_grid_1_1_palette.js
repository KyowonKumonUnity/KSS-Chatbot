var structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_palette =
[
    [ "Palette", "structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_palette.html#a0e4e1fed42db3cde48d25550a766814c", null ],
    [ "GetColor", "structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_palette.html#a2abdcb7d9174db0d4f593c9eb31a2f82", null ],
    [ "GetColorIndex", "structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_palette.html#a543d9b75db815023d3cc8227ddc7e100", null ],
    [ "LoadFromResource", "structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_palette.html#af7dfd0c7fa96daa2c9fedbace8f5f931", null ],
    [ "LoadFromText", "structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_palette.html#a25dcc30f037721003d0c41bb208e11d8", null ],
    [ "colors", "structecho17_1_1_enhanced_u_i_1_1_enhanced_grid_1_1_palette.html#a9cedfb0e7140fbc795f341b020a55dc5", null ]
];