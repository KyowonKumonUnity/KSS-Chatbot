var namespaces_dup =
[
    [ "echo17", "namespaceecho17.html", "namespaceecho17" ]
];